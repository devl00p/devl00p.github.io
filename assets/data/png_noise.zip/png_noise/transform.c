#include <pngwriter.h>
#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
/* devloop.lyua.org 02/2009 */
/* g++ -o transform transform.c `freetype-config --cflags` -lpng -lpngwriter -lz -lfreetype */

int main(int argc,char *argv[])
{
  int fd;
  struct stat fdstat;
  double side;
  unsigned int d,r,i;
  int R=0,G=0,B=0;
  unsigned int height,width,x,y,pixels;
  unsigned char *buff;
  unsigned long total;

  if(argc!=2)
  {
    printf("Usage: %s <input_file>\n",argv[0]);
    return 0;
  }

  if(stat(argv[1],&fdstat)<0)
  {
    perror("stat");
    return 1;
  }
  printf("Size of the file to hide: %ld\n",fdstat.st_size);
  d=fdstat.st_size/6;
  r=fdstat.st_size%6;
  pixels=d+1; /* 1st pixel stock original file size */
  if(r>0)pixels++;

  side=sqrt(pixels);
  height=width=round(side);
  while(height*width<pixels)height++;
  printf("Size of output png is height: %u, width: %u\n",height,width); /* final size of the generated picture */
  total=height*width;

  fd=open(argv[1],O_RDONLY);
  if(fd<0)
  {
    perror("open");
    return 1;
  }
  buff=(unsigned char*)malloc(7);
  pngwriter image(width, height, 0, "output.png");

  image.plot(1, 1, 0x0000ffff&fdstat.st_size, (0xffff0000&fdstat.st_size)>>16, 0);
  x=2;
  y=1;
  for(i=0;i<d;i++) /* write pixels calculated from the input file */
  {
    if(x>width)
    {
      x=1;
      y++;
    }
    if(read(fd,buff,6)<0)
    {
      perror("read");
      return 1;
    }
    *((unsigned char*)&R)=buff[0];
    R=R<<8;
    R=R|buff[1];

    *((unsigned char*)&G)=buff[2];
    G=G<<8;
    G=G|buff[3];

    *((unsigned char*)&B)=buff[4];
    B=B<<8;
    B=B|buff[5];

    image.plot(x, y, R, G, B);
    R=G=B=0;
    x++;
  }
  if(r>0)
  {
    if(x>width)
    {
      x=1;
      y++;
    }
    bzero(buff,6);
    if(read(fd,buff,r)<0)
    {
      perror("read");
      return 1;
    }
    *((unsigned char*)&R)=buff[0];
    R=R<<8;
    R=R|buff[1];

    *((unsigned char*)&G)=buff[2];
    G=G<<8;
    G=G|buff[3];

    *((unsigned char*)&B)=buff[4];
    B=B<<8;
    B=B|buff[5];

    image.plot(x, y, R, G, B);
    x++;
  }

  printf("%lu pixels to complete the pix.\n",total-pixels);
  while(pixels<=total)
  {
    if(x>width)
    {
      x=1;
      y++;
    }
    image.plot(x, y, R, G, B);
    x++;
    pixels++;
  }
  printf("File output.png created!\n");

  image.close();
  close(fd);
  return 0;
}
