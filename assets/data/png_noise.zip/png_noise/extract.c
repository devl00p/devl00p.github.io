#include <pngwriter.h>
#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
/* devloop.lyua.org 02/2009 */
/* g++ -o extract extract.c `freetype-config --cflags` -lpng -lpngwriter -lz -lfreetype */

int main(int argc,char *argv[])
{
  int fd;
  unsigned int d,r,i;
  int R=0,G=0,B=0;
  unsigned int height,width,x,y,file_size;
  unsigned char *buff;

  if(argc!=2)
  {
    printf("Usage: %s <input_file>\n",argv[0]);
    return 0;
  }

  pngwriter image(1, 1, 0, "out.png");
  image.readfromfile(argv[1]);
  file_size=image.read(1,1,1);
  file_size=file_size|image.read(1,1,2)<<16;
  printf("Size of the hidden file: %u\n",file_size);
  height=image.getheight();
  width=image.getwidth();
  printf("Size of the picture: height: %u, width: %u\n",height,width);
  d=file_size/6;
  r=file_size%6;
  if(r>0)d++;

  y=1;
  x=2;
  fd=open("secret_output",O_WRONLY|O_TRUNC|O_CREAT,S_IRUSR|S_IWUSR);
  if(fd<0)
  {
    perror("open");
    return 1;
  }

  buff=(unsigned char*)malloc(7);
  buff[6]='\0';
  for(i=0;i<d-1;i++)
  {
    if(x>width)
    {
      x=1;
      y++;
    }
    R=image.read(x,y,1);
    buff[0]=(unsigned char)((0x0000ff00&R)>>8);
    buff[1]=(unsigned char)(0x000000ff&R);

    G=image.read(x,y,2);
    buff[2]=(unsigned char)((0x0000ff00&G)>>8);
    buff[3]=(unsigned char)(0x000000ff&G);

    B=image.read(x,y,3);
    buff[4]=(unsigned char)((0x0000ff00&B)>>8);
    buff[5]=(unsigned char)(0x000000ff&B);
    write(fd,buff,6);
    x++;
  }

  if(r>0)
  {
    if(x>width)
    {
      x=1;
      y++;
    }
    R=image.read(x,y,1);
    buff[0]=(unsigned char)((0x0000ff00&R)>>8);
    buff[1]=(unsigned char)(0x000000ff&R);

    G=image.read(x,y,2);
    buff[2]=(unsigned char)((0x0000ff00&G)>>8);
    buff[3]=(unsigned char)(0x000000ff&G);

    B=image.read(x,y,3);
    buff[4]=(unsigned char)((0x0000ff00&B)>>8);
    buff[5]=(unsigned char)(0x000000ff&B);
    write(fd,buff,r);
  }

  close(fd);
  printf("File dumped to secret_output !\n");
  image.close();
  return 0;
}
