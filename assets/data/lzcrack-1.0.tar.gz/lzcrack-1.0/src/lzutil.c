/*
    Linux Zip Cracker v1.0 is a zip password recovery for Linux.
    It provide Brute-Force and Dictionnary attacks.

    Copyright (C) 2005 Nicolas Surribas <nicolas.surribas@free.fr>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>

#include "zip.h"

void buff2lfh(char *s,struct lfh *z)
{
  z->version=SH(s);
  z->gpf=SH(s+2);
  z->comp=SH(s+4);
  z->time=SH(s+6);
  z->date=SH(s+8);
  bcopy(s+10,&(z->crc),4);
  bcopy(s+14,&(z->zsize),4);
  bcopy(s+18,&(z->usize),4);
  z->name_len=SH(s+22);
  z->xtra_len=SH(s+24);
}

void info(struct lfh z, unsigned short n)
{
  int major, minor;
  unsigned char year;
  major=z.version/10;
  minor=z.version%10;
  printf("--------------------------\n");
  printf("[ LOCAL FILE HEADER %4u ]\n",n);
  printf("Version: %15d.%d\n",major,minor);
  printf("gpf: %21u\n",z.gpf);
  if(z.gpf&1)printf("Crypted\n");
  printf("comp: %20u\n",z.comp);
  if(z.comp==0)printf("STORED\n");
  if(z.comp&8)printf("DEFLATED\n");
  printf("time: %u\n",z.time);
  printf("time: %17.02d:%02d\n",z.time>>11,(z.time>>5)&63);
  printf("date: %u\n",z.date);
  year=(z.date>>9)+80;
  if(year>100)year-=100;
  printf("date: %14.02d/%02d/%02d\n",z.date&0x1f,(z.date>>5)&0x0f,year);
  printf("crc: %21lu\n",z.crc);
  printf("zsize: %19lu\n",z.zsize);
  printf("usize: %19lu\n",z.usize);
  printf("name_len: %16u\n",z.name_len);
  printf("xtra_len: %16u\n",z.xtra_len);
  printf("--------------------------\n");
}

void buff2cdir(char *s,struct cdir *cd)
{
  cd->vmadeby=SH(s);
  cd->vneeded=SH(s+2);
  cd->gpf=SH(s+4);
  cd->comp=SH(s+6);
  cd->time=SH(s+8);
  cd->date=SH(s+10);
  bcopy(s+12,&(cd->crc),4);
  /* cd->crc=SH(s+12); */
  bcopy(s+16,&(cd->zsize),4);
  bcopy(s+20,&(cd->usize),4);
  cd->name_len=SH(s+24);
  cd->xtra_len=SH(s+26);
  cd->comm_len=SH(s+28);
  cd->disk_num=SH(s+30);
  cd->int_attr=SH(s+32);
  bcopy(s+34,&(cd->ext_attr),4);
  bcopy(s+38,&(cd->roffset),4);
}

void cdinfo(struct cdir cd)
{
  int major, minor;
  unsigned char year;
  major=cd.vmadeby/10;
  minor=cd.vmadeby%10;
  printf("--------[ CDIR S ]--------\n");
  printf("Made by: %15d.%d\n",major,minor);
  major=cd.vneeded/10;
  minor=cd.vneeded%10;
  printf("Need version: %10d.%d\n",major,minor);
  printf("gpf: %21u\n",cd.gpf);
  printf("comp: %20u\n",cd.comp);
  /* printf("time: %u\n",cd.time); */
  printf("time: %17.02d:%02d\n",cd.time>>11,(cd.time>>5)&63);
  /* printf("date: %u\n",cd.date); */
  year=(cd.date>>9)+80;
  if(year>100)year-=100;
  printf("date: %14.02d/%02d/%02d\n",cd.date&0x1f,(cd.date>>5)&0x0f,year);
  printf("crc: %21lu\n",cd.crc);
  printf("zsize: %19lu\n",cd.zsize);
  printf("usize: %19lu\n",cd.usize);
  printf("name_len: %16u\n",cd.name_len);
  printf("xtra_len: %16u\n",cd.xtra_len);
  printf("comm_len: %16u\n",cd.comm_len);
  printf("Disk n�: %17u\n",cd.disk_num);
  printf("int_attr: %16u\n",cd.int_attr);
  printf("ext_attr: %16lu\n",cd.ext_attr);
  printf("roffset: %17lu\n",cd.roffset);
  printf("--------------------------\n");
}

void buff2eocdir(char *s, struct eocdir *eocd)
{
  eocd->disk_num=SH(s);
  eocd->disk_cd_num=SH(s+2);
  eocd->nb_cd=SH(s+4);
  eocd->nb_ent_cd=SH(s+6);
  bcopy(s+8,&(eocd->cd_size),4);
  bcopy(s+12,&(eocd->first_disk),4);
  eocd->comm_len=SH(s+16);
}

void eocdinfo(struct eocdir eocd)
{
  printf("--------[ EOCDIR ]--------\n");
  printf("Number of this disk: %u\n",eocd.disk_num);
  printf("N� of this disk with the start of the cdir: %u\n",eocd.disk_cd_num);
  printf("Start of the central directory: %u\n",eocd.nb_cd);
  printf("Central directory on this disk: %u\n",eocd.nb_ent_cd);
  printf("Size of the central directory: %lu\n",eocd.cd_size);
  printf("Starting disk number offset: %lu\n",eocd.first_disk);
  printf(".ZIP file comment length: %u\n",eocd.comm_len);
  printf("--------------------------\n");
}
