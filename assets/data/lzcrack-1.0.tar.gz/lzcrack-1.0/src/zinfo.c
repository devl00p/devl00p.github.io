/*
    Linux Zip Cracker v1.0 is a zip password recovery for Linux.
    It provide Brute-Force and Dictionnary attacks.

    Copyright (C) 2005 Nicolas Surribas <nicolas.surribas@free.fr>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>

#include "zip.h"

void usage(char *argv0);

int main(int argc,char *argv[])
{
  int fd;
  struct lfh head;
  struct cdir cds;
  struct eocdir eocds;
  char *name, *xtra, *comment;
  char buf[CDIR_LEN+1];
  int x;
  unsigned long ul,sign;
  unsigned short us, nbelem;
  
  if(argc<2)usage(argv[0]);

  nbelem=0;
  if((fd=open(argv[1],O_RDONLY))==-1)
  {
    perror("open");
    exit(1);
  }
  while(1)
  {
    if((x=read(fd,buf,sizeof(LFH_SIGN)))==-1)
    {
      perror("read");
      exit(1);
    }
    bcopy(buf,&sign,sizeof(LFH_SIGN));
    
    /* printf("sign=0x%.8lx\n",sign); */
    if(sign!=LFH_SIGN)
    {
      if(!nbelem)
      {
	fprintf(stderr,"Ce fichier n'est pas un fichier zip !\n");
	exit(1);
      }
      if(nbelem==1)
      {
	if(sign==SPSPAN_SIGN)
	{
	  printf("Found a special spanning signature\n");
	  if((x=read(fd,buf,12))==-1)
	  {
	    perror("read");
	    exit(1);
	  }
	  continue;
	}
      }
      break;
    }
    if((x=read(fd,buf,LFH_LEN-sizeof(LFH_SIGN)))==-1)
    {
      perror("read");
      exit(1);
    }
    buff2lfh(buf,&head);
    info(head,nbelem+1);
    if(head.name_len!=0)
    {
      name=(char*)malloc(1+head.name_len);
      if(read(fd,name,head.name_len)==-1)
      {
	perror("read");
	exit(1);
      }
      name[head.name_len]='\0';
      printf("file name: %15s\n",name);
      free(name);
    }
    if(head.xtra_len!=0)
    {
      xtra=(char*)malloc(1+head.xtra_len);
      if(read(fd,xtra,head.xtra_len)==-1)
      {
	perror("read");
	exit(1);
      }
      xtra[head.xtra_len]='\0';
      free(xtra);
    }
    if((ul=lseek(fd,head.zsize,SEEK_CUR))==-1)
    {
      perror("lseek");
      exit(1);
    }
    nbelem++;
  }
  printf("found %u element(s)\n",nbelem);
  nbelem=0;
  while(1)
  {
    /* printf("sign=0x%.8lx\n",sign); */
    if(sign==CDIR_SIGN)
    {
      if((x=read(fd,buf,CDIR_LEN-sizeof(CDIR_SIGN)))==-1)
      {
	perror("read");
	exit(1);
      }
      buff2cdir(buf,&cds);
      cdinfo(cds);
      if(cds.name_len!=0)
      {
	name=(char*)malloc(1+cds.name_len);
	if(read(fd,name,cds.name_len)==-1)
	{
	  perror("read");
	  exit(1);
	}
	name[cds.name_len]='\0';
	printf("file name: %15s\n",name);
	free(name);
      }
      if(cds.xtra_len!=0)
      {
	xtra=(char*)malloc(1+cds.xtra_len);
	if(read(fd,xtra,cds.xtra_len)==-1)
	{
	  perror("read");
	  exit(1);
	}
	xtra[cds.xtra_len]='\0';
	free(xtra);
      }
      if(cds.comm_len!=0)
      {
	comment=(char*)malloc(1+cds.comm_len);
	if(read(fd,comment,cds.comm_len)==-1)
	{
	  perror("read");
	  exit(1);
	}
	comment[cds.comm_len]='\0';
	free(comment);
      }
      nbelem++;
    }
    else if(sign==DIGT_SIGN)
    {
      if((x=read(fd,buf,sizeof(short)))==-1)
      {
	perror("read");
	exit(1);
      }
      us=SH(buf);
      printf("Size of signature: %u\n",us);
      if((x=read(fd,buf,us))==-1)
      {
	perror("read");
	exit(1);
      }
      break;
    }
    else
    {
      if(!nbelem)printf("End-of-central directory signature not found!\n");
      if(sign==0x06064b50L)printf("Zip64 eocdir\n");
      if(sign==0x07064b50L)printf("Zip64 eocdir\n");
      break;
    }
    if((x=read(fd,buf,sizeof(LFH_SIGN)))==-1)
    {
      perror("read");
      exit(1);
    }
    bcopy(buf,&sign,sizeof(LFH_SIGN));
  }
  if(sign==EOCDIR_SIGN)
  {
    printf("found %u element(s)\n",nbelem);
    if((x=read(fd,buf,EOCDIR_LEN-sizeof(EOCDIR_SIGN)))==-1)
    {
      perror("read");
      exit(1);
    }
    buff2eocdir(buf,&eocds);
    eocdinfo(eocds);
  }
  close(fd);
  return 0;
}

void usage(char *argv0)
{
  printf("Usage: %s <zip file>\n",argv0);
  exit(1);
}
