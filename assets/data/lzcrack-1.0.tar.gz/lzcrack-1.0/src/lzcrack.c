/*
    Linux Zip Cracker v1.0 is a zip password recovery for Linux.
    It provide Brute-Force and Dictionnary attacks.

    Copyright (C) 2005 Nicolas Surribas <nicolas.surribas@free.fr>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>
#include <getopt.h>
#include <ctype.h>

#include <zlib.h>

#include "zip.h"

#define BUF_SIZE 32
#define MIN_LEN 1
#define MAX_LEN 11

extern unsigned long mycrc32(unsigned long oldcrc, char newchar);

/* Variables globales */
unsigned char crypthead[12];
unsigned char good;
unsigned long good_crc, k0, k1, k2, pos_file, usize, zsize;
int zipfd;
int compressed;
int (*valid)();

/* D�claration de fonctions */
void update_keys(char c);
unsigned char decrypt_byte(void);
int findfile(int fd);
int test(char *s);
int svalid(void);
int zvalid(void);
int incrementalMode(int minSize, int maxSize, unsigned char minChar, unsigned char maxChar);
int dico(char *wfile);
void usage(char *argv0);
void xchange(int *a,int *b);

struct charsets
{
  char *name;
  char start;
  char end;
} charset_tab[]={
  {"lower",'a','z'},
  {"upper",'A','Z'},
  {"digit",'0','9'},
  {"all"  ,' ','~'},
  {NULL}
};

int main(int argc,char *argv[])
{
  int x,i,opt;
  int dict,inc,min,max;
  char *wfile;
  char *charset;
  char start,end;
  
  pos_file=0L;
  dict=inc=0;
  min=MIN_LEN;
  max=MAX_LEN;

  printf("[ lzcrack v1.0 - devloop - 2005 ]\n");
  while((opt=getopt(argc,argv,"HhW:w:C:c:A:a:B:b:"))!=EOF)
  {
    switch(opt)
    {
      case 'W':
      case 'w':
	if(optarg)
	{
	  if((wfile=(char*)malloc(strlen(optarg)+1))==NULL)
	  {
	    perror("malloc");
	    exit(1);
	  }
	  strcpy(wfile,optarg);
	  dict=1;
	}
	else
	{
	  usage(argv[0]);
	}
	break;
      case 'C':
      case 'c':
	if(optarg)
	{
	  if((charset=(char*)malloc(strlen(optarg)+1))==NULL)
	  {
	    perror("malloc");
	    exit(1);
	  }
	  x=0;
	  strcpy(charset,optarg);
	  while(charset_tab[x].name)
	  {
	    if(strcmp(charset,charset_tab[x].name)==0)
	    {
	      start=charset_tab[x].start;
	      end=charset_tab[x].end;
	      inc=1;
	      break;
	    }
	    x++;
	  }
	  if(inc==0)
	  {
	    fprintf(stderr,"Invalid charset !!\nValid charsets are:");
	    x=0;
	    while(charset_tab[x].name)
	    {
	      fprintf(stderr," %s",charset_tab[x].name);
	      x++;
	    }
	    printf("\n");
	    exit(1);
	  }
	}
	else
	{
	  usage(argv[0]);
	}
	break;
      case 'A':
      case 'a':
	if(optarg)
	{
	  for(i=0;i<strlen(optarg);i++)
	  {
	    if(isdigit(optarg[i])==0)
	    {
	      fprintf(stderr,"L'option -a demande un param�tre num�rique\n");
	      exit(1);
	    }
	  }
	  min=atoi(optarg);
	}
	else
	{
	  usage(argv[0]);
	}
	break;
      case 'B':
      case 'b':
	if(optarg)
	{
	  for(i=0;i<strlen(optarg);i++)
	  {
	    if(isdigit(optarg[i])==0)
	    {
	      fprintf(stderr,"L'option -b demande un param�tre num�rique\n");
	      exit(1);
	    }
	  }
	  max=atoi(optarg);
	}
	else
	{
	  usage(argv[0]);
	}
	break;
      case 'H':
      case 'h':
	usage(argv[0]);
	break;
      case '?':
	break;
      default:
	printf("?? getopt returned character code 0%o ??\n",opt);
    }
  }
  if(optind==argc)usage(argv[0]);
  if((zipfd=open(argv[argc-1],O_RDONLY))==-1)
  {
    perror("open");
    exit(1);
  }
  if(!findfile(zipfd))
  {
    if((x=read(zipfd,crypthead,12))==-1)
    {
      perror("read");
      exit(1);
    }
    printf("Encrypted header: ");
    for(i=0;i<12;i++)
      printf("%.2X",crypthead[i]);
    printf("\n");
    pos_file=lseek(zipfd,0,SEEK_CUR);
    printf("CRC to find : %lu\n",good_crc);
    if(compressed==1)valid=zvalid;
    else valid=svalid;
    if(dict==1)
    {
      if(!dico(wfile))
      {
	free(wfile);
      }
    }
    if(inc==1)
    {
      if(min>max)xchange(&min,&max);
      if(!incrementalMode(min,max,start,end))
      {
	free(charset);
      }
    }
    if(!inc && !dict)
    {
      incrementalMode(min,max,'a','z');
    }
  }
  close(zipfd);
  printf("\nTerminated\n");
  return 0;
}

void usage(char *argv0)
{
  int i=0;
  printf("Usage: %s [-w word_file] [-c charset] [-a min_len] [-b max_len] zip_file\n",argv0);
  printf("Valid charsets are:");
  while(charset_tab[i].name)
  {
    printf(" %s",charset_tab[i].name);
    i++;
  }
  printf("\n\n");
  exit(1);
}

void xchange(int *a,int *b)
{
  int tmp=*a;
  *a=*b;
  *b=tmp;
}

void update_keys(char c)
{
  k0=mycrc32(k0,c);
  k1=k1+(k0 & 0x000000ff);
  k1=k1*134775813L+1;
  k2=mycrc32(k2,(char)(k1>>24));
}

unsigned char decrypt_byte(void)
{
  unsigned char res;
  unsigned short temp;
  temp=(unsigned short)(k2|2);
  res=(unsigned char)((temp * (temp^1))>>8);
  return res;
}

int findfile(int fd)
{
  int x;
  struct lfh head;
  char *name, *xtra;
  char buf[CDIR_LEN+1];
  unsigned long sign;
  unsigned short nbelem;

  nbelem=0;
  printf("Scanning file...\n");
  while(1)
  {
    if((x=read(fd,buf,sizeof(LFH_SIGN)))==-1)
    {
      perror("read");
      exit(1);
    }
    bcopy(buf,&sign,sizeof(LFH_SIGN));

    if(sign!=LFH_SIGN)
    {
      if(!nbelem)
      {
	fprintf(stderr,"Ce fichier n'est pas un fichier zip !\n");
	exit(1);
      }
      if(nbelem==1)
      {
	if(sign==SPSPAN_SIGN)
	{
	  printf("Found a special spanning signature\n");
	  if((x=read(fd,buf,12))==-1)
	  {
	    perror("read");
	    exit(1);
	  }
	  continue;
	}
      }
      break;
    }
    if((x=read(fd,buf,LFH_LEN-sizeof(LFH_SIGN)))==-1)
    {
      perror("read");
      exit(1);
    }
    buff2lfh(buf,&head);
    if(head.name_len!=0)
    {
      name=(char*)malloc(1+head.name_len);
      if(read(fd,name,head.name_len)==-1)
      {
	perror("read");
	exit(1);
      }
      name[head.name_len]='\0';
      printf("%s\n",name);
      free(name);
    }
    if(head.xtra_len!=0)
    {
      xtra=(char*)malloc(1+head.xtra_len);
      if(read(fd,xtra,head.xtra_len)==-1)
      {
	perror("read");
	exit(1);
      }
      free(xtra);
    }
    if(head.usize!=0) /* Pour les r�pertoires */
    {
      if(head.gpf&1) /* fichier crypt� */
      {
	if((head.comp&8) || (head.comp==0)) /* Defalted ou Stored */
	{
	  if(head.comp==0)
	  {
	    compressed=0;
	    printf("File is stored\n");
	  }
	  else
	  {
	    compressed=1;
	    printf("File is deflated\n");
	  }
	  if(head.gpf&8)
	    good=buf[7];
	  else
	    good=buf[13];
	  printf("Found an encrypted file !!\n");
	  good_crc=head.crc;
	  usize=head.usize;
	  zsize=head.zsize;
	  return 0;
	}
      }
    }
    nbelem++;
  }
  fprintf(stderr,"File don't seem to be crypted !!\n");
  return 1;
}

int test(char *s)
{
  int i;
  unsigned char c;
  unsigned char buffer[12];
  
  k0=305419896L;
  k1=591751049L;
  k2=878082192L;

  for(i=0;i<strlen(s);i++)
    update_keys(s[i]);
  for(i=0;i<12;i++)
  {
    c=crypthead[i]^decrypt_byte();
    update_keys(c);
    buffer[i]=c;
  }
  if(buffer[11]==good)return 0;
  return 1;
}

int svalid(void)
{
  unsigned long crc,reste;
  int n,i;
  char c;
  unsigned char inbuffer[BUF_SIZE];
  
  crc=crc32(0L,Z_NULL,0);
  lseek(zipfd,pos_file,SEEK_SET);
  reste=usize;
  while((n=read(zipfd,inbuffer,(reste>BUF_SIZE)?BUF_SIZE:reste)))
  {
    reste-=n;
    for(i=0;i<n;i++)
    {
      c=inbuffer[i]^decrypt_byte();
      update_keys(c);
      inbuffer[i]=c;
    }
    crc=crc32(crc,inbuffer,n);
  }
  if(good_crc==crc)return 0;
  else return 1;
}

int zvalid(void)
{
  unsigned long crc;
  int err=Z_OK,i;
  char c;
  unsigned char inbuffer[BUF_SIZE];
  unsigned char outbuffer[BUF_SIZE];
  struct z_stream_s zstrm;

  crc=crc32(0L,Z_NULL,0);

  lseek(zipfd,pos_file,SEEK_SET);
  zstrm.avail_in=read(zipfd,inbuffer,(zsize<BUF_SIZE)?zsize:BUF_SIZE);

  for(i=0;i<zstrm.avail_in;i++)
  {
    c=inbuffer[i]^decrypt_byte();
    update_keys(c);
    inbuffer[i]=c;
  }

  zstrm.next_out=outbuffer;
  zstrm.avail_out=BUF_SIZE;
  zstrm.next_in=inbuffer;
  zstrm.zalloc=(alloc_func)Z_NULL;
  zstrm.zfree=(free_func)Z_NULL;
  zstrm.opaque=Z_NULL;

  if((err=inflateInit2(&zstrm,-15))!=Z_OK)
  {
    fprintf(stderr,"InflateInit2\n");
    exit(1);
  }
  while(err!=Z_STREAM_END)
  {
    while(zstrm.avail_out>0)
    {
      err=inflate(&zstrm,Z_NO_FLUSH);
      if(err!=Z_OK && err!=Z_STREAM_END)
      {
	err=inflateEnd(&zstrm);
	if(err!=Z_OK)
	{
	  if(zstrm.msg)
	  {
	    fprintf(stderr,"Erreur: %s\n",zstrm.msg);
	    exit(1);
	  }
	  else
	  {
	    fprintf(stderr,"Erreur: inflateEnd\n");
	    exit(1);
	  }
	}
	return 1;
      }
      if(err==Z_STREAM_END)
	break;
      if(zstrm.avail_in<=0)
      {
	zstrm.avail_in=read(zipfd,inbuffer,((zsize-zstrm.total_in)<BUF_SIZE)?(zsize-zstrm.total_in):BUF_SIZE);
	for(i=0;i<zstrm.avail_in;i++)
	{
	  c=inbuffer[i]^decrypt_byte();
	  update_keys(c);
	  inbuffer[i]=c;
	}
	zstrm.next_in=inbuffer;
      }
    }
    crc=crc32(crc,outbuffer,(zstrm.avail_out==0)?BUF_SIZE:(BUF_SIZE-zstrm.avail_out));
    zstrm.next_out=outbuffer;
    zstrm.avail_out=BUF_SIZE;
  }
  err=inflateEnd(&zstrm);
  if(err!=Z_OK)
  {
    fprintf(stderr,"Erreur inflateEnd\n");
    exit(1);
  }
  if(good_crc==crc)return 0;
  else return 1;
}

int incrementalMode(int minSize, int maxSize, unsigned char minChar, unsigned char maxChar)
{
  char *tmpPass;
  int tmpSize,position;

  printf("\nBrute force mode\n");
  printf("Length: %d -> %d\n",minSize,maxSize);
  printf("Chars :'%c' -> '%c'\n",minChar,maxChar);

  tmpPass=(char *)malloc(maxSize+1);
  for(tmpSize=minSize;tmpSize<=maxSize;tmpSize++)
  {
    memset(tmpPass,minChar,tmpSize);
    tmpPass[tmpSize]='\0';

    printf("Trying length %d\n",tmpSize);
    while(tmpPass[0]<=maxChar)
    {
      if(!test(tmpPass))
      {
	if(!valid())
	{
	  printf("\nPassword is: %s\n",tmpPass);
	  return 0;
	}
      }
      tmpPass[tmpSize-1]++;

      for(position=tmpSize-1;position>0;position--)
      {
	if(tmpPass[position]>maxChar)
	{
	  tmpPass[position]=minChar;
	  tmpPass[position-1]++;
	}
	else break;
      }
    }
  }
  free(tmpPass);
  return 1;
}

int dico(char *wfile)
{
  FILE *fd;
  char line[BUF_SIZE];

  if((fd=fopen(wfile,"r"))==NULL)
  {
    perror("fopen");
    exit(1);
  }
  printf("\nUsing dictionnary file: %s\n",wfile);
  while(fgets(line,BUF_SIZE,fd)!=NULL)
  {
    line[strlen(line)-1]='\0';
    if(!test(line))
    {
      if(!valid())
      {
	printf("\nPassword is: %s\n",line);
	fclose(fd);
	return 0;
      }
    }
  }
  fclose(fd);
  return 1;
}
